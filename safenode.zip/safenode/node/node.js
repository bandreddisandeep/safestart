var http =require("http");
var fs = require("fs");

var path = require("path");
var qs = require("querystring");
const express = require('express');
const app = express();
const router = express.Router();

app.use(express.static(__dirname+''))
app.use(express.static('../html'));
app.use(express.static('../js'));

http.createServer(function(req,res){

	if(req.method === "GET")
	{
		res.writeHead(200,{"Content-Type": "text/html"});

		fs.createReadStream("../html/new2.html","utf8").pipe(res);

    }else if(req.method==="POST")
    {
    	var body="";
    	req.on("data",function(chunk){
    		body+=chunk;




    	});
    	req.on("end",function()
    	{
    		//res.writeHead(200,{"Content-Type":"text/html"});
            //fs.createReadStream("new.html","utf8").pipe(res);

    		/*res.end(
    			`
    				<html>
    				<body>
    				<h1>result</h2>
    				<p>${body}</p>
    				</body>
    				</html>
    			`
    			);

		*/

			var post = qs.parse(body);
			//console.log(post);
            //console.log(post.firstName); 

			var firstname = post.firstName;
            var lastname = post.lastName;
			//console.log(firstname);


			/*fs.readFile('new.json', function(err,data)
			{
				var json = JSON.parse(data);
				json.push('firstname:'+firstname);
				fs.writeFile('new.json',JSON.stringify(json));
			});   	*/

            var obj ={
                table:[]
            };
//            obj.table.push({firstname:firstname,lastname:lastname})	;
           // var json = JSON.stringify(obj);
            fs.readFile('new1.json','utf8',function readf(err,data)
            {
                if(err) {
                console.log(err);
            }else
            {
                obj=JSON.parse(data);
                obj.table.push({firstname:firstname,lastname:lastname});
                json=JSON.stringify(obj);



            
            fs.writeFile('new1.json',json,'utf8',function(err)
                {
                    if(err) throw err;
                    console.log("completed");
                });

            

        }});
            fs.readFile('new1.json','utf8',function re(err,dat)
            {
                if(err)
                {
                    console.log(err);
                }
                else{
                    obj=JSON.parse(dat);
                   // cou = Object.keys(obj.table);
                    //len=cou.length;
                    //console.log(len);
                    //console.log(obj.table);
                
            
                
            res.end(
                `
                <html>
                <body>
                ${
                    obj.table[i].firstname
                }
                </body
                </html>
                `
           
       
                );
        
        }});


    	});
        
    }

}).listen(3000);

console.log("../"+__dirname);