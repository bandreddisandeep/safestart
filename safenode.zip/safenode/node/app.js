const express = require('express');
const app = express();
const router = express.Router();


router.get('/new',function(req,res){
	res.sendFile('../new.html');
});

app.use(express.static('../html'));
app.use(express.static('../js'));