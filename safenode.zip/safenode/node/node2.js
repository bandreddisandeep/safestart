var http = require('http');
var fs = require('fs');
var express = require('express');
var app = express();
var path = require('path');
var promise = require('promise');
console.log(__dirname);
app.use(express.static('safenode/static'));

app.get("/").then(function(req,res){
	res.sendFile(path.join(__dirname , '../html/home.html'));
});


app.listen(5000);







/*

http.createServer(function(req,res)
{
	if(req.url==='/')
	{
		fs.readFile("../html/home.html",function(err,data)
	{
		
			res.writeHead(200,{"Content-Type":"text/html"});
			res.write(data);
		

	res.end();
	});
	}
	else if(req.url==="/about")
	{
		fs.readFile("../html/about.html",function(err,data)
		{
			res.writeHead(200,{"Content-Type":"text/html"});
			res.write(data);

			res.end();
		});
	}else if(req.url==="/contacts")
	{
		fs.readFile("../html/contacts.html",function(err,data)
		{
			res.writeHead(200,{"Content-Type":"text/html"});
			res.write(data);

			res.end();
		});
	}else if(req.url==="/register")
	{
		fs.readFile("../html/register.html",function(err,data)
		{
			res.writeHead(200,{"Content-Type":"text/html"});
			res.write(data);

			res.end();
		});
	}
	
console.log(req.url);

}).listen(5000);*/
