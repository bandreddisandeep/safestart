var http = require('http');
var fs = require('fs');
var express = require('express');
var app = express();
var path = require('path');
var qs = require("querystring");
const bodyparser = require("body-parser");

console.log(__dirname);

app.use(bodyparser.urlencoded({extended: true}));
app.use('/cssFiles',express.static(__dirname + '/static'));
app.use('/images',express.static(__dirname + '/images'));
app.use('/json' ,express.static(__dirname + '/html/static'));


app.get("/" , function(req,res){
	res.sendFile(path.join(__dirname , '/html/home.html'));
});

app.get("/about",function(req,res)
{
	res.sendFile(path.join(__dirname, '/html/about.html'));
});

app.get("/contacts", function(req,res)
{
	res.sendFile(path.join(__dirname, '/html/contacts.html'));
});
app.get("/:email", function(req,res){
	var dat = req.params;
	fs.readFile('html/static/new.json','utf8',function re(err,data)
	{
		if(err){
			console.log(err);
		}
		else{
			var obj = JSON.parse(data);
			for (var i in obj.table){
				for(var x in obj.table[i]){
					//if (dat.email = obj.table[i][x]){

					if(dat.email==obj.table[i][x])
					{
						var obj1={
								table:[]
							};
							var t=[];
							var temp =[];
						for (var y in obj.table[i])
						{
							t.push(y);
							temp.push(obj.table[i][y]);
					console.log("key:"+y+" value:"+obj.table[i][y]);
				}
					obj1.table.push({firstname:temp[0],lastname:temp[1],email:temp[2],contact:temp[3],id:temp[4]});
					json1=JSON.stringify(obj1,null,2);

					fs.writeFile('html/static/new1.json',json1,'utf8',function(err)
		                {
		                    if(err) throw err;
		                    console.log("completed");
		                    res.sendFile(path.join(__dirname, '/html/show.html'));
		                });
				}
				}
			}
		}
	});
	//res.send(dat.email);

});

app.get("/register", function(req,res)
{
	//var s=[1,2,3,4];
	//var x = 1;
	//if s.includes(x){
	res.sendFile(path.join(__dirname, '/html/register.html'));
//}
});

app.post("/register" , function(req, res)
{
		var firstname = req.body.firstname;
		var lastname = req.body.lastname;
		var email = req.body.email;
		var contact = req.body.contact;
		var id = req.body.id;
		var obj ={
			table:[]
		};

		fs.readFile('html/static/new.json','utf8',function readf(err,data)
            {
                if(err) {
                console.log(err);
            }else
            {
                obj=JSON.parse(data);
                obj.table.push({firstname:firstname,lastname:lastname, email:email,contact:contact, id:id});
                json=JSON.stringify(obj,null ,2);



            
            fs.writeFile('html/static/new.json',json,'utf8',function(err)
                {
                    if(err) throw err;
                    console.log("completed");
                });

            

        }});
       // alert("sended");
		res.sendFile(path.join(__dirname, '/html/register.html'));

	//res.end();
});



app.listen(5000);



		
	







